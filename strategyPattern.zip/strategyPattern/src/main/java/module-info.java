module ku.cs.strategypattern {
    requires javafx.controls;
    requires javafx.fxml;


    opens ku.cs.Store to javafx.fxml;
    exports ku.cs.Store;
    exports ku.cs.Store.Count;
    opens ku.cs.Store.Count to javafx.fxml;
}