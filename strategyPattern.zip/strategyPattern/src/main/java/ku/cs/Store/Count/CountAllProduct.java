package ku.cs.Store.Count;

import ku.cs.Store.Product;

import java.util.List;

public class CountAllProduct implements Counter {
    @Override
    public int count(List<Product> products) {
        return products.size();
    }
    //    ณัฐชยา มะนุ่น 6510450321

}


