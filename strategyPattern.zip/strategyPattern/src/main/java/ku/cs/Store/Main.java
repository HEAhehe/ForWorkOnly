package ku.cs.Store;

import ku.cs.Store.Count.CountAllProduct;
import ku.cs.Store.Count.CountProductInStock;
import ku.cs.Store.Count.CountProductQuantity;
import ku.cs.Store.Count.Counter;

public class Main {
    public static void main(String[] args) {
        Store store = new Store();
        store.addProduct("Big Java", 300, 5);
        store.addProduct("Da Vinci Code", 120, 0);
        store.addProduct("Python 101", 200, 10);

        Counter countAll = new CountAllProduct();
        Counter countInStock = new CountProductInStock();
        Counter countQuantity = new CountProductQuantity();

        int allProducts = store.countProduct(countAll);
        int productsInStock = store.countProduct(countInStock);
        int totalQuantity = store.countProduct(countQuantity);

        System.out.println("Total Products: " + allProducts);
        System.out.println("Products In Stock: " + productsInStock);
        System.out.println("Total Quantity: " + totalQuantity);
    }
    //    ณัฐชยา มะนุ่น 6510450321

}
