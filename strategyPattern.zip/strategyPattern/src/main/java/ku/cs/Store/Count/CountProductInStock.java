package ku.cs.Store.Count;

import ku.cs.Store.Product;

import java.util.List;

public class CountProductInStock implements Counter {
    @Override
    public int count(List<Product> products) {
        int count = 0;
        for (Product prod : products) {
            if (prod.getQuantity() > 0)
                count++;
        }
        return count;
    }
    //    ณัฐชยา มะนุ่น 6510450321

}