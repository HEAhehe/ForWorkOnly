package ku.cs.Store.Count;

import ku.cs.Store.Product;

import java.util.List;

public interface Counter {
    int count(List<Product> products);
    //    ณัฐชยา มะนุ่น 6510450321

}
