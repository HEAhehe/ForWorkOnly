package ku.cs.Email.Send;

import ku.cs.Email.Email;

public interface Sender {
    void sendEmail(Email m);
    //    ณัฐชยา มะนุ่น 6510450321

}
