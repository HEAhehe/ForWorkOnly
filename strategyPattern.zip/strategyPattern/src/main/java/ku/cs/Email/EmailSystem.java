package ku.cs.Email;

import ku.cs.Email.Send.Sender;

public class EmailSystem {
    public void sendEmail(Sender sender, Email m) {
        sender.sendEmail(m);
    }
    //    ณัฐชยา มะนุ่น 6510450321

}
