module ku.cs.swconemail {
    requires javafx.controls;
    requires javafx.fxml;


    opens ku.cs.swconemail to javafx.fxml;
    exports ku.cs.swconemail;

    exports ku.cs.controllers;
    opens ku.cs.controllers to javafx.fxml;

    exports ku.cs.models;
    opens ku.cs.models to javafx.fxml;

    exports ku.cs.services;
    opens ku.cs.services to javafx.fxml;
}