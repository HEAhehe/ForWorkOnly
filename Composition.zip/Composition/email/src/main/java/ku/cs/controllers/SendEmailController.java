package ku.cs.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import ku.cs.models.Current;
import ku.cs.models.Email;
import ku.cs.models.Inbox;
import ku.cs.services.EmailListFileDatasource;

import java.io.IOException;

public class SendEmailController {
    @FXML
    private BorderPane root;
    @FXML
    private TextField SendToTextField;
    @FXML
    private TextArea ContentTextArea;
    private EmailListFileDatasource emailListFileDatasource;
    private Inbox emailList;

    @FXML
    private void initialize() throws IOException {
        root.setLeft(FXMLLoader.load(getClass().getResource("/ku/cs/views/menu.fxml")));
        emailListFileDatasource = new EmailListFileDatasource("data", "email-list.csv");
        emailList = emailListFileDatasource.readData();
    }

    @FXML
    private void handleSend() {
        String current = Current.getInstance().getCurrentUser();
        Email email = new Email(current, SendToTextField.getText(), ContentTextArea.getText());
        emailList.addEmail(email);
        emailListFileDatasource.writeData(emailList);
    }
    //    ณัฐชยา มะนุ่น 6510450321

}
