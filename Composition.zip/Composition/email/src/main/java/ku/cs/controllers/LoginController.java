package ku.cs.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import ku.cs.models.Current;
import ku.cs.services.FXRouter;

import java.io.IOException;

public class LoginController {
    @FXML
    private TextField usernameTextField;

    @FXML
    private void handleLogin() throws IOException {
        String username = usernameTextField.getText();
        Current.getInstance().setCurrentUser(username);
        FXRouter.goTo("send");
    }

//    ณัฐชยา มะนุ่น 6510450321

}