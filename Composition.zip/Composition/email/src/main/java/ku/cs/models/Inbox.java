package ku.cs.models;

import java.util.ArrayList;

public class Inbox {
    private ArrayList<Email> emailList;
    public Inbox() {
        emailList = new ArrayList<>();
    }
    public void addEmail(Email email) {
        emailList.add(email);
    }
    public ArrayList<Email> getEmailList() {
        return emailList;
    }
    //    ณัฐชยา มะนุ่น 6510450321

}
