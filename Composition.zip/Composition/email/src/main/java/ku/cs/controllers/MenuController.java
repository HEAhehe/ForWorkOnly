package ku.cs.controllers;

import javafx.fxml.FXML;
import ku.cs.services.FXRouter;

import java.io.IOException;

public class MenuController {
    @FXML
    private void goToSendEmail() throws IOException {
        FXRouter.goTo("send");
    }

    @FXML
    private void goToReadEmail() throws IOException {
        FXRouter.goTo("read");
    }

    @FXML
    private void logOut() throws IOException {
        FXRouter.goTo("login");
    }
    //    ณัฐชยา มะนุ่น 6510450321
}
