package ku.cs.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import ku.cs.models.Current;
import ku.cs.models.Email;
import ku.cs.models.Inbox;
import ku.cs.services.EmailListFileDatasource;

import java.io.IOException;

public class ReadEmailController {
    @FXML
    private TableView tableView;
    @FXML
    private BorderPane root;

    private EmailListFileDatasource emailListFileDatasource;
    private Inbox emailList;

    @FXML
    private void initialize() throws IOException {
        root.setLeft(FXMLLoader.load(getClass().getResource("/ku/cs/views/menu.fxml")));
        emailListFileDatasource = new EmailListFileDatasource("data", "email-list.csv");
        emailList = emailListFileDatasource.readData();

        showTable(emailList);
    }

    private void showTable(Inbox emailList) {
        TableColumn<Email, String> senderColumn = new TableColumn<>("Sender");
        senderColumn.setCellValueFactory(new PropertyValueFactory<>("sender"));

        TableColumn<Email, String> recipientColumn = new TableColumn<>("Recipient");
        recipientColumn.setCellValueFactory(new PropertyValueFactory<>("recipient"));

        TableColumn<Email, String> textColumn = new TableColumn<>("Text");
        textColumn.setCellValueFactory(new PropertyValueFactory<>("text"));

        tableView.getColumns().clear();
        tableView.getColumns().add(senderColumn);
        tableView.getColumns().add(recipientColumn);
        tableView.getColumns().add(textColumn);
        tableView.getItems().clear();

        for (Email email : emailList.getEmailList()) {
            tableView.getItems().add(email);
        }
    }
//    ณัฐชยา มะนุ่น 6510450321

}
