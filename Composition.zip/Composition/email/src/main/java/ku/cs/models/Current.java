package ku.cs.models;

public class Current {
    private static Current instance;
    private String currentUser;

    public static Current getInstance() {
        if (instance == null) {
            instance = new Current();
        }
        return instance;
    }

    public String getCurrentUser() {
        return currentUser;
    }
    public void setCurrentUser(String user) {
        currentUser = user;
    }
    //    ณัฐชยา มะนุ่น 6510450321

}
