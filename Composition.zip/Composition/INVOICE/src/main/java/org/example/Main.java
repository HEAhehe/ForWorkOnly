package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Invoice invoice = new Invoice();

        while (true) {
            System.out.print("Enter product name (or 'done' to finish): ");
            String description = scanner.nextLine();

            if (description.equalsIgnoreCase("done")) {
                break;
            }
            System.out.print("Enter price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter quantity: ");
            int quantity = scanner.nextInt();
            scanner.nextLine();
            Product product = new Product(description, price, quantity);
            invoice.addProduct(product);
        }
        invoice.displayInvoice();
    }
    //    ณัฐชยา มะนุ่น 6510450321

}
